/*
    libparted
    Copyright (C) 1998, 1999, 2000 Free Software Foundation, Inc.

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301, USA
*/

#ifndef FATIO_H_INCLUDED
#define FATIO_H_INCLUDED

#include "fat.h"

extern int fat_read_fragments (PedFileSystem* fs, char* buf, FatFragment frag,
			       FatFragment count);
extern int fat_write_fragments (PedFileSystem* fs, char* buf, FatFragment frag,
			        FatFragment count);
extern int fat_write_sync_fragments (PedFileSystem* fs, char* buf,
				     FatFragment frag, FatFragment count);

extern int fat_read_fragment (PedFileSystem* fs, char* buf, FatFragment frag);
extern int fat_write_fragment (PedFileSystem* fs, char* buf, FatFragment frag);
extern int fat_write_sync_fragment (PedFileSystem* fs, char* buf,
				    FatFragment frag);

extern int fat_read_clusters (PedFileSystem* fs, char* buf, FatCluster cluster,
			      FatCluster count);
extern int fat_write_clusters (PedFileSystem* fs, char* buf, FatCluster cluster,
			       FatCluster count);
extern int fat_write_sync_clusters (PedFileSystem* fs, char* buf,
				    FatCluster cluster, FatCluster count);

extern int fat_read_cluster (PedFileSystem* fs, char *buf, FatCluster cluster);
extern int fat_write_cluster (PedFileSystem* fs, char *buf, FatCluster cluster);
extern int fat_write_sync_cluster (PedFileSystem* fs, char *buf,
				   FatCluster cluster);

#endif /* FATIO_H_INCLUDED */
