
HDF Tool
========

A cross-platform command line utility for manipulating Humax Download Format
(HDF) files.

HDF Tool v1.0.2, by af123, 2011.

Syntax: humidify [options] <filename>
  -C                   Skip checksum validation.
  -c <arguments>       Create HDF file ('-c help' for more).
  -d<level>            Enable debugging at level.
  -l                   Show contents of HDF file (default).
  -o                   Use old-style checksum blocks when creating.
  -r                   Don't compress blocks when creating.
  -S<section>          Extract only the numbered section.
  -t                   Test archive (validate checksums).
  -x                   Extract files.
  -s                   Also show/extract member checksums.


Examples:

  View HDF:    humidify file.hdf
  Test HDF:    humidify -t file.hdf
  Extract HDF: humidify -x file.hdf
  Create HDF:  humidify -c file.hdf (run 'humidify -c help' for more)

