/*just convert a plain text to c-string. Not tested, using only for AVInfo compilation */
/* LICENCE: Public domain , (c) George Shuklin, 2004 :-P */
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char* argv[]){
	FILE* file=fopen(argv[1],"rb");
	char* buffer;
	int size;
	int c;
	int state=0;
	if(!file||(int)file==-1) return 32; /*error*/
	fseek(file,0,SEEK_END);
	size=ftell(file);
	fseek(file,0,SEEK_SET);
	buffer=malloc(size+1);
	fread(buffer,size,1,file);
	buffer[size]=0;
	puts("{");
	for(c=0;c<=size;c++){
		if(buffer[c]==31) {state=!state; continue;}
		if( !buffer[c]) continue;
		switch(state){
			case 0:
				switch(buffer[c]){
					case '\\': printf("\\\\");
								break;
					case '\n':  break;
					case '"': printf ("\\\"");
								break;
					case 0: break;
					default: printf("%c",buffer[c]);
				}
				break;
			case 1:
					printf ("%c",buffer[c]);
					break;
		}
	}
	puts("\n};");
	fclose(file);
	return 0;
}
	
