#ifndef _H_VER_H
#define _H_VER_H
#define AVINFO_SIGNATURE "AVInfo"
#define AVINFO_VERSION "1.0 alpha 15"
#define AVINFO_SUBNAME "[Balalaika]"
#endif
