#ifndef _H_IFO_H
#define _H_IFO_H
#include "avinfo.h"
extern int ifoparse(FILE* file, int s);
#endif
